﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PersonInfo
{
    public interface IRebel
    {
        string Group { get; }
    }
}
